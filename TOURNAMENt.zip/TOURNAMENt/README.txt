                                                  #SWISS TOURNAMENT PAIRING SYSTEM-Relational Databases#

->This project includes the Database created on the basis of Swiss tournament system

#INSTALLATION:

 . We need to install Python 2.
 . Install Postgress.

#USAGE:

  .open python IDLE.
  .open tournament.py using python IDLE.

#SETTING UP DATABASE:
  
  . $ psql -f tournament.sql
  . $ python tournament_test.py

## Files 

**tournament.py**  

Contains the implementation for the Swiss tournament  

**tournament.sql**  

Contains the SQL queries to create the database, tables and views   

**tournament_test.py**  

Contains the test cases for tournament.py  

